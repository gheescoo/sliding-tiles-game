const play = document.querySelector("div[id='playground']");
const params = new URL(document.location).searchParams;
const level = parseInt(params.get("level"));
const n_row = parseInt(params.get("row"));
const n_col = parseInt(params.get("col"));

function splitChunks(arr, chunkSize) {
    const result = [];
    for(let i = 0; i < arr.length; i += chunkSize) {
        result.push(arr.slice(i, i + chunkSize));
    }
    return result;
}

function randomShuffleBySHA256(list, seed) {
    const seedSHA = (x) => parseInt(CryptoJS.SHA256(x.toString() + seed.toString()), 16);
    return list.sort((a, b) => seedSHA(a) - seedSHA(b));
}

function initTable(level) {
    const n_total = n_row * n_col - 1;
    let tileList = Array.from({length: n_total}, (_, index) => index + 1);
    tileList = randomShuffleBySHA256(tileList, level);
    tileJsonData = splitChunks(tileList, n_col);
    const playtable = new gridjs.Grid({data: tileJsonData});
    playtable.render(play);

    playtable.on("cellClick", (...args) => console.log(args));
}

function main() {
    initTable(level);
}

main();

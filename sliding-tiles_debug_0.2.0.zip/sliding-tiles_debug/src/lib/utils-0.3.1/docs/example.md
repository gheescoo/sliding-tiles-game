# Utils object

> This is to help visualize how the `utils` object looks

All utils from all categories are placed on the `_` object. 

```js
{%= utils_methods("index.js") %}
```

const play = document.querySelector("div[id='playground']");
const scoreboard = document.querySelector("table[id='scoreboard']");
const body = document.querySelector("body");
const params = new URL(document.location).searchParams;
const level = params.get("level");
const size = parseInt(params.get("size"));

const MILLISECONDS_PER_MINUTE = 60 * 1000;
const MILLISECONDS_PER_SECOND = 1000;
const SECONDS_PER_MINUTE = 60;

const nC = size * size;
const nS = nC - 1;
const position = new Array(nC); //postion[node] refers to its array postion
const recorder = {stack: new Array(0), buf: 0};

let globalStartTimer, globalStopTimer;

async function animation(num) {

}
function checkPosition() {
    for(let i = 1; i <= nS; ++i) {
        if(position[i] != i - 1) return false;
    }
    return true;
}

function moveTile(num) {
    // console.log(num, "has been clicked");

    swapElements(play.querySelector(`canvas[id='${num}']`), play.querySelector("canvas[id='0']"));
    [position[num], position[0]] = [position[0], position[num]];
    animation(num);

    if(checkPosition()) globalStopTimer();
}

async function afterImplete() {
    const number = document.querySelector("form input[name='size']");
    const text = document.querySelector("form input[name='level']");
    number.setAttribute("value", size);
    text.setAttribute("value", level);
}

function initTiles() {
    let tileList = Array.from({length: nS}, (_, index) => index + 1);
    tileList.push(0);
    const tileHash = Array.from({length: nC}, (_, index) => Array.from(new Uint8Array(sha256(new TextEncoder().encode(index.toString() + level))))[0]);
    // console.log(tileHash);

    // Shuffles the array
    for(let i = 0; i < nS; ++i) {
        let idx = tileHash[i] % (nS - 1);
        idx += idx < i? 0: 1;
        [tileList[i], tileList[idx]] = [tileList[idx], tileList[i]];
        // console.log(`Swapped ${i} and ${idx}`);
    }
    if(isOdd(nS)) {
        [tileList[0], tileList[nS - 1]] = [tileList[nS - 1], tileList[0]];
    }

    play.style.gridTemplateColumns = `repeat(${size}, 1fr)`;

    for(let i = 0; i < nC; ++i) {
        const num = tileList[i];
        const numStr = num.toString();
        let canvas = document.createElement("canvas");
        position[num] = i;

        canvas.setAttribute("id", numStr);
        canvas.width = canvas.height = body.offsetWidth / size;

        if(num != 0) {
            canvas.addEventListener("click", () => {
                if(isAdjust(position[num], position[0], size)) {
                    moveTile(num);
                    recorder.record(num);
                }
            });
            const ctx = canvas.getContext("2d");
            ctx.font = "30px Arial";
            ctx.fillText(numStr, 20, 40);
        }

        play.appendChild(canvas);
    }
}

function updateStep() {
    document.querySelector("#stepcount").innerText = `Step: ${recorder.buf}`;
}

function initScoreboard() {
    recorder.undo = function() {
        if(this.buf <= 0) return -1;
        moveTile(this.stack[--this.buf]);
        updateStep();
        return 0;
    };
    recorder.redo = function() {
        if(this.buf >= this.stack.length) return -1;
        moveTile(this.stack[this.buf++]);
        updateStep();
        return 0;
    };
    recorder.record = function(num) {
        this.stack[this.buf++] = num;
        if(this.buf < this.stack.length) this.stack.length = this.buf;
        updateStep();
        return 0;
    }

    document.querySelector("input[id='undo']").addEventListener("click", recorder.undo.bind(recorder));
    document.querySelector("input[id='redo']").addEventListener("click", recorder.redo.bind(recorder));
}

function initTimer() {
    let startTime = null;
    let timerInterval = null;

    function startTimer() {
        startTime = new Date().getTime();
        timerInterval = setInterval(updateTimer, MILLISECONDS_PER_SECOND);
    }

    function updateTimer() {
        const currentTime = new Date().getTime();
        const elapsedTime = currentTime - startTime;

        const minutes = Math.floor(elapsedTime / MILLISECONDS_PER_MINUTE);
        const seconds = Math.floor(elapsedTime / MILLISECONDS_PER_SECOND % SECONDS_PER_MINUTE);

        document.querySelector("#timeused").innerText = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }

    function stopTimer() {
        clearInterval(timerInterval);
    }

    globalStartTimer = startTimer;
    globalStopTimer = stopTimer;
}

initTiles();
initScoreboard();
initTimer();
globalStartTimer();
if(checkPosition()) globalStopTimer();
afterImplete();

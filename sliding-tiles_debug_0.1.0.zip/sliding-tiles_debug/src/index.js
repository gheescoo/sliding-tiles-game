const play = document.querySelector("div[id='playground']");
const body = document.querySelector("body");
const params = new URL(document.location).searchParams;
const level = params.get("level");
const size = parseInt(params.get("size"));

const position = new Array(size * size); //postion[node] refers to its array postion

async function animation(num) {

}

function moveTile(num) {
    console.log(num, "has been clicked");

    if(isAdjust(position[num], position[0], size)) {
        swapElements(play.querySelector(`canvas[id='${num}']`), play.querySelector("canvas[id='0']"));
        [position[num], position[0]] = [position[0], position[num]];
        animation(num);
    }
}

async function afterImplete() {
    const number = document.querySelector("form input[name='size']");
    const text = document.querySelector("form input[name='level']");
    number.setAttribute("value", size);
    text.setAttribute("value", level);
}

function initTiles(level) {
    const n_total = size * size - 1;
    let tileList = Array.from({length: n_total}, (_, index) => index + 1);
    const tileHash = Array.from({length: n_total}, (_, index) => CryptoJS.SHA256(index.toString() + level).words[0]);
    tileList = tileList.sort((a, b) => tileHash[a] - tileHash[b]);

    play.style.gridTemplateColumns = `repeat(${size}, 1fr)`;

    for(let i = 0; i < n_total; ++i) {
        const num = tileList[i];
        const numStr = num.toString();
        let canvas = document.createElement("canvas");
        position[num] = i;

        canvas.addEventListener("click", () => moveTile(num));
        canvas.setAttribute("id", numStr);
        canvas.width = canvas.height = body.offsetWidth / size;

        const ctx = canvas.getContext("2d");
        ctx.font = "30px Arial";
        ctx.fillText(numStr, 20, 40);

        play.appendChild(canvas);
    }

    let canvas = document.createElement("canvas");
    position[0] = n_total;

    canvas.setAttribute("id", "0");
    canvas.width = canvas.height = body.offsetWidth / size;

    play.appendChild(canvas);
}

initTiles();
afterImplete();

const params = new URL(document.location).searchParams;
var size = parseInt(params.get("size"));
var level = params.get("level");

window.wallpaperPropertyListener = {
    applyUserProperties: function(properties) {
        if(properties.size) {
            const tSize = parseInt(properties.size.value);
            size = tSize > 1? tSize: size;
        }
        if(properties.level) {
            const tLevel = properties.level.value;
            level = tLevel;
        }
        refreshPage();
    },
};
